create definer = avnadmin@`%` view vw_expense_summary as
select `u`.`id`                                                                 AS `user_id`,
       `u`.`username`                                                           AS `username`,
       date_format(`m`.`dateOfPayment`, '%Y-%m')                                AS `month`,
       `m`.`category`                                                           AS `category`,
       count(0)                                                                 AS `transaction_count`,
       sum((case when (`m`.`amount` < 0) then abs(`m`.`amount`) else 0 end))    AS `total_expenses`,
       sum((case when (`m`.`amount` > 0) then `m`.`amount` else 0 end))         AS `total_income`,
       count((case when (`m`.`reason` is not null) then 1 end))                 AS `expenses_with_reason`,
       avg((case when (`m`.`amount` < 0) then abs(`m`.`amount`) else NULL end)) AS `avg_expense`
from (`defaultdb`.`mysaving2` `m` join `defaultdb`.`users` `u` on ((`m`.`user_id` = `u`.`id`)))
group by `u`.`id`, `u`.`username`, date_format(`m`.`dateOfPayment`, '%Y-%m'), `m`.`category`;

